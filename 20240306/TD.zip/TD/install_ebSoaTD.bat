"D:\BDI\REG\gacutil.exe" -u ebSoa.ebSoa.TimeDeposit,Version=1.3.0.0,Culture=Neutral,PublicKeyToken=f686be03daca0324

pause

"D:\BDI\REG\gacutil.exe" -i D:\BDI\DRIB\CoreV1.3\ebSoa.TimeDeposit.dll

pause
iisreset