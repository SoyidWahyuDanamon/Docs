INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK21','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK22','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK23','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK24','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');



INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK05','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK06','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK07','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK08','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK09','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK10','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');



INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK11','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK12','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK13','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK14','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK15','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK16','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK17','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK18','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');


INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK19','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');



INSERT INTO creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def
(id, plan_code, program_desc, program_code, program_name_eng, program_name_indo, flag_status, created_by, created_time)
VALUES((select max(id)+1 from creditcard.tbl_bdi_omni_cc_moi_elig_plan_code_def) ,'UK20','Balance Conversion','03','My Own Installment - Statement (Balance Conversion)','My Own Installment - Statement (Balance Conversion)','A','DBPI-1928','now()');




